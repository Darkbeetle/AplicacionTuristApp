define({
  "_themeLabel": "Skladací motív",
  "_layout_default": "Predvolené rozloženie",
  "_layout_layout1": "Rozloženie 1"
});