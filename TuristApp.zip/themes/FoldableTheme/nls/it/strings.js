define({
  "_themeLabel": "Tema avviluppabile",
  "_layout_default": "Layout predefinito",
  "_layout_layout1": "Layout 1"
});