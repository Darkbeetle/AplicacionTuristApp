define({
  "_themeLabel": "موضوع قابل للطي",
  "_layout_default": "تخطيط افتراضي",
  "_layout_layout1": "تخطيط 1"
});