define({
  "_themeLabel": "Foldbar-tema",
  "_layout_default": "Standardoppsett",
  "_layout_layout1": "Oppsett 1"
});