define({
  "_themeLabel": "折疊式主題",
  "_layout_default": "預設版面配置",
  "_layout_layout1": "排版 1"
});